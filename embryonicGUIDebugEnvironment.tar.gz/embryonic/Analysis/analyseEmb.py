#timeline test script
import timeline





a=timeline.analyseGraph()
	#a.getJSONResults()
a.getMYSQLResults()
a.dumpResults(a.parse())
#a.processTimeline()

	#if changed == True:
